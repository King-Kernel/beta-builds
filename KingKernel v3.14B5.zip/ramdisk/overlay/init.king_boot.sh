#!/system/bin/sh
#(c)kingbri KingKernel on boot tweaks

# Trim selected partitions at boot for a more than well-deserved and nice speed boost;
fstrim /data;
fstrim /cache;
fstrim /system;

#Force enable cpu3
echo "1" > /sys/devices/system/cpu/cpu3/online

#Enable core control & msm_thermal for lesser cpu usage
echo "1" > /sys/module/msm_thermal/core_control/enabled
echo "Y" > /sys/module/msm_thermal/parameters/enabled

# Rework doze settings for better battery life, temperature, etc...
settings put global device_idle_constants light_after_inactive_to=0,light_pre_idle_to=0,light_idle_to=300000,light_idle_factor=2.0,light_max_idle_to=900000,light_idle_maintenance_min_budget=5000,light_idle_maintenance_max_budget=10000,min_light_maintenance_time=2000,min_deep_maintenance_time=2000,inactive_to=180000,sensing_to=0,locating_to=0,location_accuracy=50.0,motion_inactive_to=60000,idle_after_inactive_to=0,idle_pending_to=15000,max_idle_pending_to=120000,idle_pending_factor=2.0,idle_to=1200000,max_idle_to=21600000,idle_factor=2.0,min_time_to_alarm=3600000,max_temp_app_whitelist_duration=20000,mms_temp_app_whitelist_duration=0,sms_temp_app_whitelist_duration=15000,notification_whitelist_duration=30000


