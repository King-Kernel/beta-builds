#!/system/bin/sh

# RAM variables for LMK calculator

TOTAL_RAM=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`;
memg=$(awk -v x=$TOTAL_RAM 'BEGIN{print x/1048576}')
ROUND_memg=$(round ${memg} 0)

#xfirefly's cpuset profile to be applied when device is finished booting

# A customized CPUSet profile for the first generation of Pixels (By xfirefly93) - with the goal of increasing both battery life, system responsivness and overall daily needed performance without any notable regressions, possible sacrifices and tradeoffs;
echo "3" > /dev/cpuset/background/cpus
echo "1,3" > /dev/cpuset/camera-daemon/cpus
echo "0-1" > /dev/cpuset/foreground/cpus
echo "2" > /dev/cpuset/kernel/cpus
echo "2-3" > /dev/cpuset/restricted/cpus
echo "2-3" > /dev/cpuset/system-background/cpus
echo "0-3" > /dev/cpuset/top-app/cpus

# Script log file location
LOG_FILE=/storage/emulated/0/logs

export TZ=$(getprop persist.sys.timezone);
echo $(date) > /storage/emulated/0/logs/extraslog
if [ $? -eq 0 ]
then
  echo "All extras have been applied" >> /storage/emulated/0/logs/extraslog
  exit 0
else
  echo "Extras did not apply :(" >> /storage/emulated/0/logs/extraslog
  exit 1
fi
