#!/system/bin/sh

# RAM variables for LMK calculator

TOTAL_RAM=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`;
memg=$(awk -v x=$TOTAL_RAM 'BEGIN{print x/1048576}')
ROUND_memg=$(round ${memg} 0)

#xfirefly's cpuset profile to be applied when device is finished booting

# A customized CPUSet profile for the first generation of Pixels (By xfirefly93) - with the goal of increasing both battery life, system responsivness and overall daily needed performance without any notable regressions, possible sacrifices and tradeoffs;
echo "3" > /dev/cpuset/background/cpus
echo "1,3" > /dev/cpuset/camera-daemon/cpus
echo "0-1" > /dev/cpuset/foreground/cpus
echo "2" > /dev/cpuset/kernel/cpus
echo "2-3" > /dev/cpuset/restricted/cpus
echo "2-3" > /dev/cpuset/system-background/cpus
echo "0-3" > /dev/cpuset/top-app/cpus

#LKT's LMK calculator tuned by kingbri for the kernel

#I like the stock LMK, but it seems to not be up to my standards. Each boot, the LMK is calculated when everything settles down (This is why the sleep timer exists)

sleep 35;
if [ $TOTAL_RAM -lt 2097152 ]; then
    calculator="2.70"

elif [ $TOTAL_RAM -lt 3145728 ]; then
    calculator="2.75"
    resetprop -n ro.sys.fw.bg_apps_limit 32

elif [ $TOTAL_RAM -lt 4194304 ]; then
    calculator="2.85"
    resetprop -n ro.sys.fw.bg_apps_limit 36
fi

if [ $TOTAL_RAM -gt 4194304 ]; then
    calculator="3.45"
    resetprop -n ro.sys.fw.bg_apps_limit 48

elif [ $TOTAL_RAM -gt 6291456 ]; then
    calculator="4.65"
    resetprop -n ro.sys.fw.bg_apps_limit 78
fi

  # LMK Calculator
  # This is a Calculator for the Android Low Memory Killer
  # It detects the Free RAM and set the LMK to right configuration
  # for more RAM but also better Multitasking
  # Algorithms COPYRIGHT by PDesire and the THDR Alliance
  # Code COPYRIGHT korom42


divisor=$(awk -v x=$TOTAL_RAM 'BEGIN{print x/256}')
var_one=$(awk -v x=$TOTAL_RAM -v y=2 'BEGIN{print sqrt(x)*sqrt(2)}')
var_two=$(awk -v x=$TOTAL_RAM -v p=3.14 'BEGIN{print x*sqrt(p)}')
var_three=$(awk -v x=$var_one -v y=$var_two -v z=$divisor 'BEGIN{print (x+y)/z}')
var_four=$(awk -v x=$var_three -v p=3.14 'BEGIN{print x/(sqrt(p)*2)}')
f_LMK=$(awk -v x=$var_four -v p=3.14 'BEGIN{print x/(p*2)}')
LMK=$(round ${f_LMK} 0)


 # Low Memory Killer Generator
 # Settings inspired by HTC stock firmware
 # Tuned by korom42 for multi-tasking and saving CPU cycles

f_LMK1=$(awk -v x=$LMK -v y=$calculator 'BEGIN{print x*y*1024/4}') #Low Memory Killer 1
LMK1=$(round ${f_LMK1} 0)

f_LMK2=$(awk -v x=$LMK1 -v y=$calculator 'BEGIN{print x*1.25}') #Low Memory Killer 2
LMK2=$(round ${f_LMK2} 0)

f_LMK3=$(awk -v x=$LMK1 -v y=$calculator 'BEGIN{print x*1.75}') #Low Memory Killer 3
LMK3=$(round ${f_LMK3} 0)

f_LMK4=$(awk -v x=$LMK1 -v y=$calculator 'BEGIN{print x*2.25}') #Low Memory Killer 4
LMK4=$(round ${f_LMK4} 0)

f_LMK5=$(awk -v x=$LMK1 -v y=$calculator 'BEGIN{print x*3.33}') #Low Memory Killer 5
LMK5=$(round ${f_LMK5} 0)

f_LMK6=$(awk -v x=$LMK1 -v y=$calculator 'BEGIN{print x*4.25}') #Low Memory Killer 6
LMK6=$(round ${f_LMK6} 0)

LMK1=$((LMK1/2))
LMK1=$(round ${LMK1} 0)


if [ -e "/sys/module/lowmemorykiller/parameters/enable_adaptive_lmk" ]; then
    set_value 1 /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
fi

if [ -e "/sys/module/lowmemorykiller/parameters/minfree" ]; then
   set_value "$LMK1,$LMK2,$LMK3,$LMK4,$LMK5,$LMK6" /sys/module/lowmemorykiller/parameters/minfree
   resetprop -n lmk.autocalc true
fi
