#!/system/bin/sh
#(c)kingbri KingKernel on boot tweaks

# Trim selected partitions at boot for a more than well-deserved and nice speed boost;
fstrim /data;
fstrim /cache;
fstrim /system;

# A customized CPUSet profile for the first generation of Pixels (By xfirefly93) - with the goal of increasing both battery life, system responsivness and overall daily needed performance without any notable regressions, possible sacrifices and tradeoffs;
echo "3" > /dev/cpuset/background/cpus
echo "1,3" > /dev/cpuset/camera-daemon/cpus
echo "0-1" > /dev/cpuset/foreground/cpus
echo "2" > /dev/cpuset/kernel/cpus
echo "2-3" > /dev/cpuset/restricted/cpus
echo "2-3" > /dev/cpuset/system-background/cpus
echo "0-3" > /dev/cpuset/top-app/cpus

#sleep for a second because stupid rom tweaks can be executed
sleep 2;

#Force enable cpu3
echo "1" > /sys/devices/system/cpu/cpu3/online

#Enable core control & msm_thermal for lesser cpu usage
echo "1" > /sys/module/msm_thermal/core_control/enabled
echo "Y" > /sys/module/msm_thermal/parameters/enabled
